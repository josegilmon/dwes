<?php

// variables para identificar cada una de las preferencias que se pueden configurar
$idioma = "idioma";
$perfil = "perfil";
$zona = "zona";

// en este array guardamos la descripción de cada una de las preferencias
$preferencias = [$idioma => "Idioma", $perfil => "Perfil Público", $zona => "Zona Horaria"];

?>
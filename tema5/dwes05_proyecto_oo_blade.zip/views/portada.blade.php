@extends('app')
@section('titulo', "Portada")
@section('encabezado', "Acceder a la información")
@section('contenido')
    <a href="productos.php" class="btn btn-info mr-4">Acceder a Productos</a>
    <a href="familias.php" class="mr-4 btn btn-info">Acceder a Familias</a>
@endsection
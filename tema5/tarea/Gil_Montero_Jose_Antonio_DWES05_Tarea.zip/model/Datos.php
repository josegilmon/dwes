<?php
namespace App;

class Datos {

    public const POSICIONES = ['Portero', 'Defensa', 'Lateral Izquierdo', 'Lateral Derecho', 'Central', 'Delantero'];

}
